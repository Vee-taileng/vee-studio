const cityForm = document.querySelector("form");
const card = document.querySelector(".card");
const detail = document.querySelector(".details");
const time = document.querySelector("img.time");
const icon = document.querySelector(".icon img");


// Update UI
const updateUI = data=>{
    // const citiDets = data.cityDets;
    // const weather = data.weather;

    // Destructuring Properties
    const {cityDets, weather} = data;

    detail.innerHTML = `
        <h3>${cityDets.EnglishName}</h3>
        <div class="weather-condition">${weather.WeatherText}</div>
        <div>
        <span>${weather.Temperature.Metric.Value}</span>
        <span>&deg;C</span>
        </div>
    `
    const iconSrc = `img/icons/${weather.WeatherIcon}.svg`;
    icon.setAttribute("src", iconSrc)

    // let timeSrc = null;
    // if(weather.IsDayTime){
    //     timeSrc = 'img/day.svg'
    // }else{
    //     timeSrc = 'img/night.svg'
    // }
    const timeSrc = weather.IsDayTime? 'img/day.svg': 'img/night.svg';
    time.setAttribute("src", timeSrc)
    card.style.display = "block";
}

// update city
const updateCity = async (city)=>{
    
    const cityDets = await getCity(city);
    const weather = await getWeather(cityDets.Key);

    return {cityDets, weather}
}

cityForm.addEventListener("submit", e =>{
    // Prevent Default Action
    e.preventDefault()

    const city = cityForm.city.value.trim()
    cityForm.reset()

    updateCity(city)
    .then(data => updateUI(data))
    .catch(err=>console.log(err))
})
